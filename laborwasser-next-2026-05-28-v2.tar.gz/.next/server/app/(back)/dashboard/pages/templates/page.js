(()=>{var e={};e.id=2537,e.ids=[2537],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},12412:e=>{"use strict";e.exports=require("assert")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},31833:e=>{e.exports={templateGallery:"TemplateGallery_templateGallery__bzx9W",header:"TemplateGallery_header__HmX1Q",title:"TemplateGallery_title__7VAeZ",subtitle:"TemplateGallery_subtitle__gPqPY",templates:"TemplateGallery_templates__HX799",templateCard:"TemplateGallery_templateCard__1h_pT",templateOverlay:"TemplateGallery_templateOverlay__cyL9s",templateThumbnail:"TemplateGallery_templateThumbnail__gXjK2",thumbnailPlaceholder:"TemplateGallery_thumbnailPlaceholder__5DhLv",previewButton:"TemplateGallery_previewButton__c6EoP",templateInfo:"TemplateGallery_templateInfo__ma3Q5",templateName:"TemplateGallery_templateName__nGg0C",templateDescription:"TemplateGallery_templateDescription__7m5E4",templateActions:"TemplateGallery_templateActions__j3Pxm",useButton:"TemplateGallery_useButton__yw2DP",previewModal:"TemplateGallery_previewModal__ZxCtl",previewContent:"TemplateGallery_previewContent__T6Z06",previewHeader:"TemplateGallery_previewHeader__q8_x3",previewBody:"TemplateGallery_previewBody__gjWKw",previewIframe:"TemplateGallery_previewIframe__pDdKo",previewFooter:"TemplateGallery_previewFooter__qRidd"}},33873:e=>{"use strict";e.exports=require("path")},41169:(e,s,a)=>{"use strict";a.r(s),a.d(s,{default:()=>t});let t=(0,a(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/(back)/dashboard/pages/templates/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/(back)/dashboard/pages/templates/page.tsx","default")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},67572:(e,s,a)=>{"use strict";a.r(s),a.d(s,{GlobalError:()=>l.default,__next_app__:()=>d,pages:()=>n,routeModule:()=>p,tree:()=>r});var t=a(65239),i=a(48088),l=a(31369),c=a(30893),o={};for(let e in c)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>c[e]);a.d(s,o);let r={children:["",{children:["(back)",{children:["dashboard",{children:["pages",{children:["templates",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,41169)),"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/(back)/dashboard/pages/templates/page.tsx"]}]},{}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,86110)),"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/(back)/layout.tsx"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(a.bind(a,94431)),"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/layout.tsx"],error:[()=>Promise.resolve().then(a.bind(a,54431)),"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/error.tsx"],"global-error":[()=>Promise.resolve().then(a.bind(a,31369)),"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/global-error.tsx"],"not-found":[()=>Promise.resolve().then(a.bind(a,54413)),"/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/not-found.tsx"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,70440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,n=["/home/jadwer/dev/AtomoSoluciones/base/webapp-base/src/app/(back)/dashboard/pages/templates/page.tsx"],d={require:a,loadChunk:()=>Promise.resolve()},p=new t.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/(back)/dashboard/pages/templates/page",pathname:"/dashboard/pages/templates",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:r}})},74075:e=>{"use strict";e.exports=require("zlib")},79280:(e,s,a)=>{Promise.resolve().then(a.bind(a,41169))},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},89008:(e,s,a)=>{Promise.resolve().then(a.bind(a,91760))},91760:(e,s,a)=>{"use strict";a.r(s),a.d(s,{default:()=>h});var t=a(60687),i=a(43210),l=a(33650),c=a(67472),o=a(19253);let r=[{id:"laborwasser-enhanced-landing",name:"LaborWasser Enhanced Landing",category:"Landing Pages",description:"Landing page completa con integraci\xf3n del cat\xe1logo p\xfablico avanzado",thumbnail:"/templates/laborwasser-enhanced.jpg",tags:["landing","catalog","products","laborwasser","enhanced"],html:`
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Labor Wasser de M\xe9xico - Cat\xe1logo Avanzado</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header -->
    <header class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <i class="bi bi-droplet me-2"></i>
                Labor Wasser
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#inicio">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#productos">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#ofertas">Ofertas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contacto">Contacto</a>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="inicio" class="hero-section bg-gradient bg-primary text-white py-5">
        <div class="container">
            <div class="row align-items-center min-vh-75">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">
                        Reactivos y Material de Laboratorio de Calidad Superior
                    </h1>
                    <p class="lead mb-4">
                        M\xe1s de 20 a\xf1os distribuyendo productos qu\xedmicos y equipos cient\xedficos 
                        con certificaci\xf3n internacional y asesor\xeda especializada.
                    </p>
                    <div class="d-flex flex-column flex-md-row gap-3">
                        <a href="#productos" class="btn btn-light btn-lg">
                            <i class="bi bi-grid-3x3-gap me-2"></i>
                            Ver Cat\xe1logo
                        </a>
                        <a href="#cotizacion" class="btn btn-outline-light btn-lg">
                            <i class="bi bi-calculator me-2"></i>
                            Solicitar Cotizaci\xf3n
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <i class="bi bi-flask display-1 opacity-75"></i>
                </div>
            </div>
        </div>
    </section>

    <!-- Ofertas del Mes Enhanced -->
    <section id="ofertas" class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="display-5 fw-bold text-success mb-3">
                        <i class="bi bi-tag-fill me-3"></i>
                        OFERTAS DEL MES
                    </h2>
                    <p class="lead text-muted mb-4">
                        Aprovecha nuestras mejores promociones en productos de laboratorio
                    </p>
                    <div class="alert alert-success border-0 shadow-sm d-inline-block mb-4">
                        <i class="bi bi-clock me-2"></i>
                        <strong>\xa1Tiempo limitado!</strong> V\xe1lido hasta fin de mes
                    </div>
                </div>
            </div>

            <!-- Productos en oferta -->
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4 mb-5">
                <div class="col">
                    <div class="card h-100 shadow border-success position-relative">
                        <div class="position-absolute top-0 start-0 m-2">
                            <span class="badge bg-success fs-6">-25%</span>
                        </div>
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-warning text-dark">OFERTA</span>
                        </div>
                        <div class="ratio ratio-4x3">
                            <div class="d-flex align-items-center justify-content-center bg-light">
                                <i class="bi bi-flask text-success" style="font-size: 4rem;"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <span class="badge bg-success bg-opacity-10 text-success small">LaborWasser</span>
                                <span class="badge bg-primary bg-opacity-10 text-primary small">Reactivos</span>
                            </div>
                            <h5 class="card-title">Kit de Reactivos B\xe1sicos</h5>
                            <p class="card-text">
                                Conjunto completo de 12 reactivos esenciales para an\xe1lisis qu\xedmico b\xe1sico.
                            </p>
                            <div class="mb-3">
                                <div class="d-flex align-items-center">
                                    <span class="text-decoration-line-through text-muted me-2">$4,500.00</span>
                                    <span class="fw-bold fs-4 text-success">$3,375.00</span>
                                </div>
                                <small class="text-muted">Ahorra $1,125.00</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-success flex-grow-1">
                                    <i class="bi bi-cart-plus me-1"></i> Aprovechar Oferta
                                </button>
                                <button class="btn btn-outline-secondary">
                                    <i class="bi bi-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card h-100 shadow border-success position-relative">
                        <div class="position-absolute top-0 start-0 m-2">
                            <span class="badge bg-success fs-6">-15%</span>
                        </div>
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-warning text-dark">OFERTA</span>
                        </div>
                        <div class="ratio ratio-4x3">
                            <div class="d-flex align-items-center justify-content-center bg-light">
                                <i class="bi bi-thermometer text-info" style="font-size: 4rem;"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <span class="badge bg-info bg-opacity-10 text-info small">ChemTech</span>
                                <span class="badge bg-warning bg-opacity-10 text-warning small">Instrumentos</span>
                            </div>
                            <h5 class="card-title">Term\xf3metro Digital Premium</h5>
                            <p class="card-text">
                                Precisi\xf3n \xb10.1\xb0C, rango -50\xb0C a 300\xb0C, certificaci\xf3n incluida.
                            </p>
                            <div class="mb-3">
                                <div class="d-flex align-items-center">
                                    <span class="text-decoration-line-through text-muted me-2">$2,890.00</span>
                                    <span class="fw-bold fs-4 text-success">$2,456.50</span>
                                </div>
                                <small class="text-muted">Ahorra $433.50</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-success flex-grow-1">
                                    <i class="bi bi-cart-plus me-1"></i> Aprovechar Oferta
                                </button>
                                <button class="btn btn-outline-secondary">
                                    <i class="bi bi-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card h-100 shadow border-success position-relative">
                        <div class="position-absolute top-0 start-0 m-2">
                            <span class="badge bg-success fs-6">-30%</span>
                        </div>
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-danger">\xdaLTIMAS PIEZAS</span>
                        </div>
                        <div class="ratio ratio-4x3">
                            <div class="d-flex align-items-center justify-content-center bg-light">
                                <i class="bi bi-eyedropper text-warning" style="font-size: 4rem;"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <span class="badge bg-warning bg-opacity-10 text-warning small">LabPro</span>
                                <span class="badge bg-info bg-opacity-10 text-info small">Material</span>
                            </div>
                            <h5 class="card-title">Set Completo de Micropipetas</h5>
                            <p class="card-text">
                                4 micropipetas de diferentes vol\xfamenes con puntas incluidas.
                            </p>
                            <div class="mb-3">
                                <div class="d-flex align-items-center">
                                    <span class="text-decoration-line-through text-muted me-2">$8,750.00</span>
                                    <span class="fw-bold fs-4 text-success">$6,125.00</span>
                                </div>
                                <small class="text-muted">Ahorra $2,625.00</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-success flex-grow-1">
                                    <i class="bi bi-cart-plus me-1"></i> Aprovechar Oferta
                                </button>
                                <button class="btn btn-outline-secondary">
                                    <i class="bi bi-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- \xdaltimos Productos Enhanced -->
    <section id="productos" class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2 class="display-5 fw-bold text-primary mb-3">\xdaLTIMOS PRODUCTOS</h2>
                    <p class="lead text-muted mb-4">
                        Descubre nuestras \xfaltimas incorporaciones al cat\xe1logo
                    </p>
                    <div class="d-flex flex-wrap justify-content-center gap-3 mb-4">
                        <div class="badge bg-primary bg-opacity-10 text-primary fs-6 px-3 py-2">
                            <i class="bi bi-box-seam me-2"></i>
                            6 productos destacados
                        </div>
                        <div class="badge bg-success bg-opacity-10 text-success fs-6 px-3 py-2">
                            <i class="bi bi-lightning me-2"></i>
                            Actualizados en tiempo real
                        </div>
                    </div>
                </div>
            </div>

            <!-- View Mode Toggle -->
            <div class="row mb-4">
                <div class="col-12 text-center">
                    <div class="btn-group" role="group">
                        <button class="btn btn-primary btn-sm active">
                            <i class="bi bi-grid-3x3-gap"></i> Grilla
                        </button>
                        <button class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-list-ul"></i> Lista
                        </button>
                        <button class="btn btn-outline-primary btn-sm">
                            <i class="bi bi-card-text"></i> Tarjetas
                        </button>
                    </div>
                </div>
            </div>

            <!-- Productos Grid -->
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 mb-5">
                <div class="col">
                    <div class="card h-100 shadow-sm position-relative">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-success">NUEVO</span>
                        </div>
                        <div class="ratio ratio-4x3">
                            <div class="d-flex align-items-center justify-content-center bg-light">
                                <i class="bi bi-box-seam text-primary" style="font-size: 3rem;"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <span class="badge bg-secondary bg-opacity-10 text-secondary small">LaborWasser</span>
                                <span class="badge bg-primary bg-opacity-10 text-primary small">Reactivos</span>
                            </div>
                            <h6 class="card-title">\xc1cido Sulf\xfarico Concentrado</h6>
                            <p class="card-text small text-muted">
                                Reactivo de alta pureza para an\xe1lisis qu\xedmico profesional.
                            </p>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fw-bold fs-5 text-primary">$2,450.00</span>
                                <small class="text-muted">/ Litro</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary btn-sm flex-grow-1">
                                    <i class="bi bi-eye me-1"></i> Ver Detalles
                                </button>
                                <button class="btn btn-outline-success btn-sm">
                                    <i class="bi bi-calculator"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card h-100 shadow-sm position-relative">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-success">NUEVO</span>
                        </div>
                        <div class="ratio ratio-4x3">
                            <div class="d-flex align-items-center justify-content-center bg-light">
                                <i class="bi bi-speedometer2 text-success" style="font-size: 3rem;"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <span class="badge bg-secondary bg-opacity-10 text-secondary small">ChemTech</span>
                                <span class="badge bg-info bg-opacity-10 text-info small">Equipos</span>
                            </div>
                            <h6 class="card-title">Balanza Anal\xedtica Digital</h6>
                            <p class="card-text small text-muted">
                                Precisi\xf3n de 0.1mg, calibraci\xf3n autom\xe1tica incluida.
                            </p>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fw-bold fs-5 text-primary">$28,750.00</span>
                                <small class="text-muted">/ Pieza</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary btn-sm flex-grow-1">
                                    <i class="bi bi-eye me-1"></i> Ver Detalles
                                </button>
                                <button class="btn btn-outline-success btn-sm">
                                    <i class="bi bi-calculator"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card h-100 shadow-sm position-relative">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-success">NUEVO</span>
                        </div>
                        <div class="ratio ratio-4x3">
                            <div class="d-flex align-items-center justify-content-center bg-light">
                                <i class="bi bi-droplet text-info" style="font-size: 3rem;"></i>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mb-2">
                                <span class="badge bg-secondary bg-opacity-10 text-secondary small">LabPro</span>
                                <span class="badge bg-warning bg-opacity-10 text-warning small">Vidrio</span>
                            </div>
                            <h6 class="card-title">Set de Pipetas Volum\xe9tricas</h6>
                            <p class="card-text small text-muted">
                                Kit completo con certificado de calibraci\xf3n.
                            </p>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="fw-bold fs-5 text-primary">$1,890.00</span>
                                <small class="text-muted">/ Set</small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-primary btn-sm flex-grow-1">
                                    <i class="bi bi-eye me-1"></i> Ver Detalles
                                </button>
                                <button class="btn btn-outline-success btn-sm">
                                    <i class="bi bi-calculator"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col d-none d-lg-block">
                    <div class="card h-100 border-2 border-dashed border-primary">
                        <div class="card-body d-flex align-items-center justify-content-center text-center">
                            <div>
                                <i class="bi bi-plus-circle display-4 text-primary mb-3"></i>
                                <h6 class="text-primary">Ver M\xe1s Productos</h6>
                                <p class="text-muted small mb-0">Explora todo el cat\xe1logo</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="row">
                <div class="col-12 text-center">
                    <div class="d-flex flex-column flex-md-row gap-3 justify-content-center">
                        <a href="/productos" class="btn btn-primary btn-lg">
                            <i class="bi bi-grid-3x3-gap me-2"></i>
                            Ver Cat\xe1logo Completo
                        </a>
                        <a href="/productos?sort=created_at" class="btn btn-outline-primary btn-lg">
                            <i class="bi bi-clock-history me-2"></i>
                            Ver Todos los Nuevos
                        </a>
                        <a href="/ofertas" class="btn btn-outline-success btn-lg">
                            <i class="bi bi-tag me-2"></i>
                            Ver Ofertas
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Cotizaci\xf3n Section -->
    <section id="cotizacion" class="py-5 bg-primary text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h3 class="fw-bold mb-2">\xbfNecesitas una cotizaci\xf3n personalizada?</h3>
                    <p class="mb-0">
                        Nuestro equipo de especialistas te ayudar\xe1 a encontrar los productos 
                        exactos para tu laboratorio con los mejores precios del mercado.
                    </p>
                </div>
                <div class="col-lg-4 text-center">
                    <button class="btn btn-light btn-lg">
                        <i class="bi bi-calculator me-2"></i>
                        Solicitar Cotizaci\xf3n
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h5 class="fw-bold mb-3">
                        <i class="bi bi-droplet me-2"></i>
                        Labor Wasser de M\xe9xico
                    </h5>
                    <p class="text-light">
                        Distribuidora especializada en reactivos y material de laboratorio 
                        con m\xe1s de 20 a\xf1os de experiencia en el mercado mexicano.
                    </p>
                </div>
                <div class="col-lg-4 mb-4">
                    <h6 class="fw-bold mb-3">Contacto</h6>
                    <div class="text-light">
                        <p class="mb-2">
                            <i class="bi bi-geo-alt me-2"></i>
                            Ciudad de M\xe9xico, M\xe9xico
                        </p>
                        <p class="mb-2">
                            <i class="bi bi-telephone me-2"></i>
                            +52 55 1234 5678
                        </p>
                        <p class="mb-2">
                            <i class="bi bi-envelope me-2"></i>
                            ventas@laborwasser.com.mx
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 mb-4">
                    <h6 class="fw-bold mb-3">Enlaces R\xe1pidos</h6>
                    <ul class="list-unstyled text-light">
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Cat\xe1logo</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Ofertas</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Cotizaciones</a></li>
                        <li class="mb-2"><a href="#" class="text-light text-decoration-none">Soporte T\xe9cnico</a></li>
                    </ul>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center text-light">
                <p class="mb-0">&copy; 2025 Labor Wasser de M\xe9xico. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    `,css:`
/* Estilos personalizados para LaborWasser Enhanced */
.hero-section {
    background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
    min-height: 100vh;
}

.min-vh-75 {
    min-height: 75vh;
}

.card {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.badge {
    font-size: 0.7rem;
}

.btn {
    transition: all 0.2s ease-in-out;
}

.btn:hover {
    transform: translateY(-1px);
}

/* View mode animations */
.btn-group .btn {
    transition: all 0.2s ease-in-out;
}

.btn-group .btn:hover:not(.active) {
    background-color: rgba(13, 110, 253, 0.1);
}

/* Product cards animations */
.position-relative .badge {
    transition: transform 0.2s ease-in-out;
}

.card:hover .badge {
    transform: scale(1.05);
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .display-4 {
        font-size: 2.5rem;
    }
    
    .display-5 {
        font-size: 2rem;
    }
    
    .hero-section {
        min-height: 80vh;
    }
}
    `},{id:"public-catalog-ecommerce",name:"Cat\xe1logo P\xfablico E-commerce",category:"E-commerce",description:"P\xe1gina de cat\xe1logo completo con filtros avanzados y carrito de compras",thumbnail:"/templates/public-catalog-ecommerce.jpg",tags:["ecommerce","catalog","filters","shopping","products"],html:`
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat\xe1logo de Productos - E-commerce Avanzado</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>
<body>
    <!-- Header con carrito -->
    <header class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="#">
                <i class="bi bi-shop me-2"></i>
                TiendaLab
            </a>
            
            <!-- Buscador central -->
            <div class="flex-grow-1 mx-4 d-none d-lg-block">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Buscar productos...">
                    <button class="btn btn-primary">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </div>

            <!-- Carrito y usuario -->
            <div class="d-flex align-items-center gap-3">
                <button class="btn btn-outline-primary position-relative">
                    <i class="bi bi-heart"></i>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        3
                    </span>
                </button>
                <button class="btn btn-primary position-relative">
                    <i class="bi bi-cart3"></i>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-success">
                        5
                    </span>
                </button>
                <button class="btn btn-outline-secondary">
                    <i class="bi bi-person"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Breadcrumb -->
    <div class="bg-light py-2">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Inicio</a></li>
                    <li class="breadcrumb-item active">Cat\xe1logo</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container-fluid py-4">
        <div class="row">
            <!-- Sidebar Filters -->
            <div class="col-lg-3 mb-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h6 class="mb-0">
                            <i class="bi bi-funnel me-2"></i>
                            Filtros
                        </h6>
                    </div>
                    <div class="card-body">
                        <!-- Categor\xedas -->
                        <div class="mb-4">
                            <h6 class="fw-bold">Categor\xedas</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cat1">
                                <label class="form-check-label" for="cat1">
                                    Reactivos Qu\xedmicos <span class="badge bg-secondary">45</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cat2">
                                <label class="form-check-label" for="cat2">
                                    Equipos de Lab <span class="badge bg-secondary">23</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cat3">
                                <label class="form-check-label" for="cat3">
                                    Material de Vidrio <span class="badge bg-secondary">67</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cat4">
                                <label class="form-check-label" for="cat4">
                                    Instrumentos <span class="badge bg-secondary">34</span>
                                </label>
                            </div>
                        </div>

                        <!-- Marcas -->
                        <div class="mb-4">
                            <h6 class="fw-bold">Marcas</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="brand1">
                                <label class="form-check-label" for="brand1">
                                    LaborWasser <span class="badge bg-secondary">123</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="brand2">
                                <label class="form-check-label" for="brand2">
                                    ChemTech <span class="badge bg-secondary">45</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="brand3">
                                <label class="form-check-label" for="brand3">
                                    LabPro <span class="badge bg-secondary">67</span>
                                </label>
                            </div>
                        </div>

                        <!-- Rango de precio -->
                        <div class="mb-4">
                            <h6 class="fw-bold">Precio</h6>
                            <div class="row g-2">
                                <div class="col">
                                    <input type="number" class="form-control form-control-sm" placeholder="M\xedn">
                                </div>
                                <div class="col-auto">-</div>
                                <div class="col">
                                    <input type="number" class="form-control form-control-sm" placeholder="M\xe1x">
                                </div>
                            </div>
                            <input type="range" class="form-range mt-2" min="0" max="50000">
                        </div>

                        <!-- Disponibilidad -->
                        <div class="mb-4">
                            <h6 class="fw-bold">Disponibilidad</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="stock1" checked>
                                <label class="form-check-label" for="stock1">
                                    En stock
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="stock2">
                                <label class="form-check-label" for="stock2">
                                    Bajo pedido
                                </label>
                            </div>
                        </div>

                        <button class="btn btn-outline-danger btn-sm w-100">
                            <i class="bi bi-x-circle me-1"></i>
                            Limpiar Filtros
                        </button>
                    </div>
                </div>
            </div>

            <!-- Products Area -->
            <div class="col-lg-9">
                <!-- Toolbar -->
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <span class="text-muted">Mostrando 1-24 de 156 productos</span>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex justify-content-end gap-3">
                                    <!-- Sort -->
                                    <select class="form-select form-select-sm" style="width: auto;">
                                        <option>Ordenar por nombre</option>
                                        <option>Precio: menor a mayor</option>
                                        <option>Precio: mayor a menor</option>
                                        <option>M\xe1s nuevos</option>
                                        <option>M\xe1s vendidos</option>
                                    </select>

                                    <!-- View Mode -->
                                    <div class="btn-group">
                                        <button class="btn btn-outline-secondary btn-sm active">
                                            <i class="bi bi-grid-3x3-gap"></i>
                                        </button>
                                        <button class="btn btn-outline-secondary btn-sm">
                                            <i class="bi bi-list-ul"></i>
                                        </button>
                                        <button class="btn btn-outline-secondary btn-sm">
                                            <i class="bi bi-card-text"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Products Grid -->
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 row-cols-xl-4 g-4 mb-4">
                    <!-- Producto 1 -->
                    <div class="col">
                        <div class="card h-100 shadow-sm position-relative">
                            <div class="position-absolute top-0 end-0 m-2 z-1">
                                <button class="btn btn-outline-light btn-sm rounded-circle">
                                    <i class="bi bi-heart"></i>
                                </button>
                            </div>
                            <div class="ratio ratio-1x1">
                                <div class="d-flex align-items-center justify-content-center bg-light">
                                    <i class="bi bi-flask text-primary" style="font-size: 3rem;"></i>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="mb-2">
                                    <span class="badge bg-primary bg-opacity-10 text-primary small">LaborWasser</span>
                                    <span class="badge bg-success bg-opacity-10 text-success small">En stock</span>
                                </div>
                                <h6 class="card-title">\xc1cido Sulf\xfarico 98%</h6>
                                <p class="card-text small text-muted">
                                    Reactivo anal\xedtico de alta pureza para laboratorio.
                                </p>
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <span class="fw-bold text-primary fs-5">$1,250.00</span>
                                        <br>
                                        <small class="text-muted">por Litro</small>
                                    </div>
                                    <div class="text-end">
                                        <div class="text-warning small">
                                            <i class="bi bi-star-fill"></i>
                                            <i class="bi bi-star-fill"></i>
                                            <i class="bi bi-star-fill"></i>
                                            <i class="bi bi-star-fill"></i>
                                            <i class="bi bi-star-half"></i>
                                        </div>
                                        <small class="text-muted">(24 reviews)</small>
                                    </div>
                                </div>
                                <div class="d-flex gap-1">
                                    <button class="btn btn-primary btn-sm flex-grow-1">
                                        <i class="bi bi-cart-plus"></i>
                                    </button>
                                    <button class="btn btn-outline-secondary btn-sm">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                    <button class="btn btn-outline-secondary btn-sm">
                                        <i class="bi bi-share"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- M\xe1s productos... (repetir estructura) -->
                    <!-- Se pueden agregar m\xe1s productos aqu\xed -->
                </div>

                <!-- Pagination -->
                <nav aria-label="Paginaci\xf3n de productos">
                    <ul class="pagination justify-content-center">
                        <li class="page-item disabled">
                            <span class="page-link"><i class="bi bi-chevron-double-left"></i></span>
                        </li>
                        <li class="page-item disabled">
                            <span class="page-link"><i class="bi bi-chevron-left"></i></span>
                        </li>
                        <li class="page-item active">
                            <span class="page-link">1</span>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#">2</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#">3</a>
                        </li>
                        <li class="page-item">
                            <span class="page-link">...</span>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#">7</a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#"><i class="bi bi-chevron-right"></i></a>
                        </li>
                        <li class="page-item">
                            <a class="page-link" href="#"><i class="bi bi-chevron-double-right"></i></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    `,css:`
/* E-commerce Catalog Styles */
.navbar {
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.card {
    transition: all 0.2s ease-in-out;
    border: 1px solid rgba(0,0,0,0.08);
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.badge {
    font-size: 0.7rem;
}

.btn {
    transition: all 0.2s ease-in-out;
}

.btn:hover {
    transform: translateY(-1px);
}

.form-check-label {
    font-size: 0.9rem;
}

.position-relative .btn {
    backdrop-filter: blur(10px);
    background-color: rgba(255,255,255,0.8);
}

.text-warning i {
    margin-right: 1px;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .d-none.d-lg-block {
        display: block !important;
        margin: 1rem 0;
    }
}
    `}],n=[{id:"static-page-generic",name:"Pagina Estatica",category:"Paginas",description:"Template generico para paginas institucionales: titulo, contenido y CTA de cotizacion",thumbnail:"/templates/static-page.jpg",tags:["static","page","institutional","content"],html:`
<!-- Hero Section -->
<div class="hero-sections" style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); padding: 60px 0; color: white;">
  <div class="container">
    <div class="row align-items-center">
      <div class="col">
        <h1 style="font-size: 2.5rem; font-weight: bold; text-transform: uppercase; margin: 0;">TITULO DE LA PAGINA</h1>
      </div>
    </div>
  </div>
</div>

<!-- Contenido Principal -->
<div class="container my-5">
  <div class="row">
    <div class="col-12">
      <p style="font-size: 1.1rem; line-height: 1.8; color: #333;">
        Escribe aqui el contenido de tu pagina. Puedes agregar texto, imagenes, listas, tablas y cualquier otro elemento HTML.
      </p>
      <p style="font-size: 1.1rem; line-height: 1.8; color: #333;">
        Este template es ideal para paginas institucionales como "Nosotros", "Aviso de Privacidad", "Certificados", etc.
      </p>
    </div>
  </div>
</div>

<!-- CTA Cotizacion -->
<section class="cta-section" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 60px 0; color: white;">
  <div class="container text-center">
    <h2 style="font-size: 2rem; font-weight: bold; margin-bottom: 15px;">\xbfNECESITAS UNA COTIZACION?</h2>
    <p style="font-size: 1.1rem; opacity: 0.9; margin-bottom: 25px;">Ponte en contacto con nosotros y uno de nuestros representantes se pondra en contacto contigo.</p>
    <a href="/productos" class="btn btn-success btn-lg" style="padding: 12px 30px; font-size: 1.1rem;">
      <i class="bi bi-cart-check me-2"></i>Cotiza ahora
    </a>
  </div>
</section>
    `.trim()}];var d=a(31833),p=a.n(d);let b=({onSelectTemplate:e,onClose:s})=>{let[a,d]=(0,i.useState)(null),b=Object.entries(c.ZR).map(([e,s])=>({id:e,category:"LaborWasser",...s})),m=[...b,...r.map(e=>({id:e.id,category:e.category,name:e.name,description:e.description,thumbnail:e.thumbnail,content:e.html})),...n.map(e=>({id:e.id,category:e.category,name:e.name,description:e.description,thumbnail:e.thumbnail,content:e.html}))],v=a=>{let t={...a};if(a.content.includes("\x3c!-- Hero Slider ser\xe1 insertado din\xe1micamente --\x3e")){let e=o.Mf.find(e=>"hero-slider"===e.id);e&&(t.content=a.content.replace("\x3c!-- Hero Slider ser\xe1 insertado din\xe1micamente --\x3e",e.content))}if(a.content.includes("\x3c!-- Hero Video ser\xe1 insertado din\xe1micamente --\x3e")){let e=o.Mf.find(e=>"hero-video"===e.id);e&&(t.content=a.content.replace("\x3c!-- Hero Video ser\xe1 insertado din\xe1micamente --\x3e",e.content))}if(a.content.includes("\x3c!-- Hero Parallax ser\xe1 insertado din\xe1micamente --\x3e")){let e=o.Mf.find(e=>"hero-parallax"===e.id);e&&(t.content=a.content.replace("\x3c!-- Hero Parallax ser\xe1 insertado din\xe1micamente --\x3e",e.content))}e(t),s&&s()},u=e=>{let s={...e};if(e.content.includes("\x3c!-- Hero Slider ser\xe1 insertado din\xe1micamente --\x3e")){let a=o.Mf.find(e=>"hero-slider"===e.id);a&&(s.content=e.content.replace("\x3c!-- Hero Slider ser\xe1 insertado din\xe1micamente --\x3e",a.content))}if(e.content.includes("\x3c!-- Hero Video ser\xe1 insertado din\xe1micamente --\x3e")){let a=o.Mf.find(e=>"hero-video"===e.id);a&&(s.content=e.content.replace("\x3c!-- Hero Video ser\xe1 insertado din\xe1micamente --\x3e",a.content))}if(e.content.includes("\x3c!-- Hero Parallax ser\xe1 insertado din\xe1micamente --\x3e")){let a=o.Mf.find(e=>"hero-parallax"===e.id);a&&(s.content=e.content.replace("\x3c!-- Hero Parallax ser\xe1 insertado din\xe1micamente --\x3e",a.content))}d(s)};return(0,t.jsxs)("div",{className:p().templateGallery,children:[(0,t.jsxs)("div",{className:p().header,children:[(0,t.jsxs)("h2",{className:p().title,children:[(0,t.jsx)("i",{className:"bi bi-layout-text-window-reverse me-2"}),"Galer\xeda de Templates"]}),(0,t.jsx)("p",{className:p().subtitle,children:"Selecciona un template profesional para comenzar tu p\xe1gina"})]}),(0,t.jsx)("div",{className:p().templates,children:(0,t.jsxs)("div",{className:"row g-4",children:[m.map(e=>(0,t.jsx)("div",{className:"col-lg-4 col-md-6",children:(0,t.jsxs)(l.Zp,{className:p().templateCard,children:[(0,t.jsxs)("div",{className:p().templateThumbnail,children:[(0,t.jsxs)("div",{className:p().thumbnailPlaceholder,children:[(0,t.jsx)("i",{className:"bi bi-file-earmark-richtext"}),(0,t.jsx)("span",{children:e.name})]}),(0,t.jsx)("div",{className:p().templateOverlay,children:(0,t.jsxs)(l.$n,{variant:"primary",size:"small",onClick:()=>u(e),className:p().previewButton,children:[(0,t.jsx)("i",{className:"bi bi-eye"})," Vista Previa"]})})]}),(0,t.jsxs)("div",{className:p().templateInfo,children:[(0,t.jsx)("h5",{className:p().templateName,children:e.name}),(0,t.jsx)("p",{className:p().templateDescription,children:e.description}),(0,t.jsx)("div",{className:p().templateActions,children:(0,t.jsxs)(l.$n,{variant:"success",size:"small",onClick:()=>v(e),className:p().useButton,children:[(0,t.jsx)("i",{className:"bi bi-check-circle"})," Usar Template"]})})]})]})},e.id)),(0,t.jsx)("div",{className:"col-lg-4 col-md-6",children:(0,t.jsxs)(l.Zp,{className:p().templateCard,children:[(0,t.jsx)("div",{className:p().templateThumbnail,children:(0,t.jsxs)("div",{className:p().thumbnailPlaceholder,children:[(0,t.jsx)("i",{className:"bi bi-file-earmark-plus"}),(0,t.jsx)("span",{children:"P\xe1gina en Blanco"})]})}),(0,t.jsxs)("div",{className:p().templateInfo,children:[(0,t.jsx)("h5",{className:p().templateName,children:"P\xe1gina en Blanco"}),(0,t.jsx)("p",{className:p().templateDescription,children:"Comienza desde cero con una p\xe1gina vac\xeda"}),(0,t.jsx)("div",{className:p().templateActions,children:(0,t.jsxs)(l.$n,{variant:"primary",size:"small",onClick:()=>v({name:"P\xe1gina en Blanco",description:"P\xe1gina vac\xeda",thumbnail:"",content:'<div class="container"><h1>Nueva P\xe1gina</h1></div>'}),className:p().useButton,children:[(0,t.jsx)("i",{className:"bi bi-plus-circle"})," Crear desde Cero"]})})]})]})})]})}),a&&(0,t.jsx)("div",{className:p().previewModal,children:(0,t.jsxs)("div",{className:p().previewContent,children:[(0,t.jsxs)("div",{className:p().previewHeader,children:[(0,t.jsx)("h3",{children:a.name}),(0,t.jsx)(l.$n,{variant:"secondary",size:"small",onClick:()=>d(null),children:(0,t.jsx)("i",{className:"bi bi-x"})})]}),(0,t.jsx)("div",{className:p().previewBody,children:(0,t.jsx)("iframe",{srcDoc:`
                  <!DOCTYPE html>
                  <html>
                    <head>
                      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
                      <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
                      <style>
                        body { margin: 0; padding: 0; }
                      </style>
                    </head>
                    <body>
                      ${a.content}
                    </body>
                  </html>
                `,className:p().previewIframe})}),(0,t.jsxs)("div",{className:p().previewFooter,children:[(0,t.jsx)(l.$n,{variant:"secondary",onClick:()=>d(null),children:"Cerrar"}),(0,t.jsxs)(l.$n,{variant:"success",onClick:()=>v(a),children:[(0,t.jsx)("i",{className:"bi bi-check-circle"})," Usar este Template"]})]})]})})]})};var m=a(60576),v=a(82141),u=a(84778);function h(){let e=(0,v.n)(),{createPage:s}=(0,m.Y_)(),[a,c]=(0,i.useState)(!1),o=async a=>{try{c(!0);let t=await s({title:`Nueva p\xe1gina desde ${a.name}`,slug:`pagina-${Date.now()}`,html:a.content,css:"",json:{},status:"draft"});if(t){let s={id:t.id,title:t.title,slug:t.slug,html:t.html,css:t.css,json:t.json,status:t.status,createdAt:t.createdAt,updatedAt:t.updatedAt,timestamp:Date.now()};localStorage.setItem(`temp-page-${t.id}`,JSON.stringify(s)),e.push(`/dashboard/page-builder/${t.id}`)}}catch(e){console.error("Error creating page from template:",e),u.o.error("Error al crear la pagina desde el template")}finally{c(!1)}};return(0,t.jsxs)("div",{className:"container-fluid py-4",children:[(0,t.jsxs)("div",{className:"d-flex justify-content-between align-items-center mb-4",children:[(0,t.jsx)("h1",{className:"h3",children:"Galer\xeda de Templates"}),(0,t.jsxs)(l.$n,{variant:"secondary",onClick:()=>{e.push("/dashboard/pages")},children:[(0,t.jsx)("i",{className:"bi bi-arrow-left me-2"}),"Volver"]})]}),a?(0,t.jsxs)("div",{className:"text-center py-5",children:[(0,t.jsx)("div",{className:"spinner-border text-primary",role:"status",children:(0,t.jsx)("span",{className:"visually-hidden",children:"Creando p\xe1gina..."})}),(0,t.jsx)("p",{className:"mt-3",children:"Creando p\xe1gina desde template..."})]}):(0,t.jsx)(b,{onSelectTemplate:o})]})}},94735:e=>{"use strict";e.exports=require("events")}};var s=require("../../../../../webpack-runtime.js");s.C(e);var a=e=>s(s.s=e),t=s.X(0,[4447,9043,2639,3832,1176,6198,234,6141,4454,8896,1133,8203,3729,9983],()=>a(67572));module.exports=t})();